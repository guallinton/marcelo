@echo off
cd /d "%~dp0"
java -cp "agenda-quimioterapia-1.3.0.jar;lib\*" com.oncologia.agenda.AppLauncher
