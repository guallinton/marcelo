@echo off
cd /d "%~dp0"
java -cp "agenda-quimioterapia-1.5.0.jar;lib\*" com.oncologia.agenda.AppLauncher
