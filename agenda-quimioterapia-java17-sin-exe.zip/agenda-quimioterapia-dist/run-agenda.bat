@echo off
cd /d "%~dp0"
java -cp "agenda-quimioterapia-1.2.0.jar;lib\*" com.oncologia.agenda.AppLauncher
