@echo off
cd /d "%~dp0"
java -cp "agenda-quimioterapia-1.4.0.jar;lib\*" com.oncologia.agenda.AppLauncher
